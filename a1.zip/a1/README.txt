To run our code, simply run the shell script runme.sh -c to compile the code. You can use the -u, -o, -p, -w options to
use the UserService, OrderService, ProductService, and Workload Parser respectively.

This was working, however now the code is not compiling and a lot of time was spent debuggin this issue.
We tried a lot of things including looking at the piazza posts, stackoverflow, asking GPT4 and more, but none of the
solutions worked. Please take a look at our code in the src directory as we know we have the main principle.