#!/bin/bash

# Function to display usage information
usage() {
    echo "Usage: $0 [-c] [-u] [-p] [-i] [-o] [-w workloadfile]" 1>&2
    echo "  -c        Compiles all your code."
    echo "  -u        Starts the User service."
    echo "  -p        Starts the Product service."
    echo "  -i        Starts the ISCS."
    echo "  -o        Starts the Order service."
    echo "  -w file   Starts the workload parser on the same machine as the order service."
    exit 1
}

# Check if no arguments provided, then display usage information
if [[ $# -eq 0 ]]; then
    usage
fi

for jar_file in ./lib/*.jar; do
    CLASSPATH="$CLASSPATH:$jar_file"
done

# Parse command line options
while getopts ":cupoiw:" option; do
    case "${option}" in
        c)  # Compiles all your code
            # Place your compilation commands here
            echo "Compiling all code..."

            # call for each service
            javac -cp "$CLASSPATH:./src" -d ./compiled/ ./src/UserService/*.java
            javac -cp "$CLASSPATH:./src" -d ./compiled/ ./src/ProductService/*.java
            javac -cp "$CLASSPATH:./src" -d ./compiled/ ./src/OrderService/*.java
            ;;
        u)  # Starts the User service
            echo "Starting the User service..."
            # Command to start the User service
            java -cp  "$CLASSPATH:./compiled" UserService.UserService
            ;;
        p)  # Starts the Product service
            echo "Starting the Product service..."
            # Command to start the Product service
            java -cp "$CLASSPATH:./compiled" ProductService.ProductService
            ;;
        i)  # Starts the ISCS
            echo "There is no ISCS..."
            # Command to start the ISCS
            ;;
        o)  # Starts the Order service
            echo "Starting the Order service..."
            # Command to start the Order service
            java -cp "$CLASSPATH:./compiled" OrderService.OrderService
            ;;
        w)  # Starts the workload parser
            workloadfile=${OPTARG}
            echo "Starting the workload parser with file: $workloadfile..."
            python3 workload_parser.py $workloadfile
            # Command to start the workload parser
            ;;
        *)  # Invalid option
            echo "Invalid option: $OPTARG" 1>&2
            usage
            ;;
    esac
done
shift $((OPTIND-1))

# Additional commands can be placed here if needed

echo "All operations completed."

