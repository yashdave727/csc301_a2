package OrderService;

import java.nio.file.Files;
import java.nio.file.Paths;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.json.JSONException;
import org.json.JSONObject;


import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

// import org.json.simple.JSONObject;

/**
 * process HTTP POST requests for placing orders, extracts order details from the HTTP request, 
 * checks for product and user validity, and if the product is available, it updates the product 
 * information to reflect the placed order.
 */

public class OrderHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        
        if ("POST".equals(method)) {

            // Read JSON file content into a String
            String configPath = Paths.get("").toAbsolutePath().toString()+"/config.json";
   
            String content = new String(Files.readAllBytes(Paths.get(configPath)));
            JSONObject config;
            JSONObject userService;
            JSONObject productService;
            Integer userPort;
            String userIp;
            Integer productPort;
            String productIp;
            try {
                config = new JSONObject(content);
                userService = config.getJSONObject("UserService");
                productService = config.getJSONObject("ProductService");
                userPort = userService.getInt("port");
                userIp = userService.getString("ip");
                productPort = productService.getInt("port");
                productIp = productService.getString("ip");
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            // Where do I use this?
            String requestURI = exchange.getRequestURI().getPath().toString();
            System.out.println(requestURI);

            if (!requestURI.equals("/order")) {
                exchange.close();
                return;

            }

            JSONObject requestJson;
            try {
                requestJson = new JSONObject(getRequestBody(exchange));
            } catch (JSONException | IOException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(404, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            if (!requestJson.has("command") || !requestJson.has("product_id") || !requestJson.has("user_id") || !requestJson.has("quantity")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            String command;
            Integer productId;
            Integer userId;
            Integer quantity;
            try {
                command = requestJson.getString("command");
                productId = requestJson.getInt("product_id");
                userId = requestJson.getInt("user_id");
                quantity = requestJson.getInt("quantity");
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(404, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            if (quantity < 0 || userId < 0 || productId < 0 || command.equals("")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            if (!command.equals("place")) {

                sendResponse(401, exchange, command);
                exchange.close();
                return;
                
            }

            String user_url = "http://"+userIp+":"+userPort+"/user/"+userId;
            String userResponse = sendGetRequest(user_url);

            JSONObject userJson;
            try {
                userJson = new JSONObject(userResponse);
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            if (!userJson.has("id")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(404, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            String product_url = "http://"+productIp+":"+productPort+"/product/"+productId;
            String productResponse = sendGetRequest(product_url);

            JSONObject productJson;
            try {
                productJson = new JSONObject(productResponse);
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(404, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            if (!productJson.has("id")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(404, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            Integer prodId;
            Integer quantityCheck;
            String productName;
            String description;
            Integer price;
            try {
                prodId = productJson.getInt("id");
                quantityCheck = productJson.getInt("quantity");
                productName =  productJson.getString("name");
                description = productJson.getString("description");
                price = productJson.getInt("price");
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }
            

            if (quantityCheck - quantity < 0) {
                
                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            String product_update_url = "http://"+productIp+":"+productPort+"/product";

            JSONObject json = new JSONObject();
            try {
                json.put("command", "update");
                json.put("id", prodId);
                json.put("name", productName);
                json.put("description", description);
                json.put("price", price);
                json.put("quantity", quantityCheck);
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            String requestBody = json.toString();

            sendPostRequest(product_update_url, requestBody);
            sendResponse(200, exchange, requestBody);
            exchange.close();
            return;

        }

        else {
            
            JSONObject jsonObject = new JSONObject();
            sendResponse(401, exchange, jsonObject.toString());
            exchange.close();   
            return;

        }

    }

    private static String getRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder requestBody = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                requestBody.append(line);
            }
            return requestBody.toString();
        }
    }

    private static void sendResponse(Integer status, HttpExchange exchange, String response) throws IOException {
        exchange.sendResponseHeaders(status, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes(StandardCharsets.UTF_8));
        os.close();
    }

    public static String sendGetRequest(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection url_connection = (HttpURLConnection) url.openConnection();
        url_connection.setRequestMethod("GET");

        StringBuilder response = new StringBuilder();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(url_connection.getInputStream()))) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
        }

        url_connection.disconnect();

        return response.toString();
    }

    public static String sendPostRequest(String urlString, String requestBody) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        // Set the request method to POST
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json"); // Adjust content type if needed
        connection.setDoOutput(true);

        // Write the request body
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = requestBody.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        // Read the response
        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
        }

        return response.toString();
    }
    
}