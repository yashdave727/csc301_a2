package OrderService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

// import org.json.simple.JSONObject;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import org.json.JSONException;
import org.json.JSONObject;


public class ProductHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        
        // Read JSON file content into a String
            String configPath = Paths.get("").toAbsolutePath().toString()+"/config.json";
   
            String content = new String(Files.readAllBytes(Paths.get(configPath)));
            JSONObject config;
            JSONObject productService;
            Integer productPort;
            String productIp;
            try {
                config = new JSONObject(content);
                productService = config.getJSONObject("ProductService");
                productPort = productService.getInt("port");
                productIp = productService.getString("ip");
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

        String requestURI = exchange.getRequestURI().getPath().toString();
        System.out.println(requestURI);

        if ("POST".equals(exchange.getRequestMethod())) {

            if (!requestURI.equals("/order/product")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            JSONObject requestJson;
            try {
                requestJson = new JSONObject(getRequestBody(exchange));
            } catch (JSONException | IOException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            if (!requestJson.has("command") || !requestJson.has("id") || !requestJson.has("name") || !requestJson.has("description") || requestJson.has("price") || requestJson.has("quantity")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            String command;
            Integer id;
            String name;
            String description;
            Double price;
            Integer quantity;
            try {
                command = requestJson.getString("command");
                id = requestJson.getInt("id");
                name = requestJson.getString("name");
                description = requestJson.getString("description");
                price = requestJson.getDouble("price");
                quantity = requestJson.getInt("quantity");
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            String product_url = "http://"+productIp+":"+productPort+"/product";
            JSONObject json = new JSONObject();

            try {
                json.put("command", command);
                json.put("id", id);
                json.put("name", name);
                json.put("description", description);
                json.put("price", price);
                json.put("quantity", quantity);
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }
            
            String requestBody = json.toString();

            if (command.equals("create") || command.equals("update") || command.equals("delete")) {
                String postResponse = sendPostRequest(product_url, requestBody);
                sendResponse(exchange.getResponseCode(), exchange, postResponse);
                System.out.println("Product POST response code in PS: "+exchange.getResponseCode());
                exchange.close();
                return;
            }
            else {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

        }
        else if ("GET".equals(exchange.getRequestMethod())) {
            
            String[] URISplit = requestURI.split("/");
            String id = URISplit[URISplit.length - 1];
            
            String user_url = "http://"+productIp+":"+productPort+"/product/"+id;
            String userResponse = sendGetRequest(user_url);
            sendResponse(exchange.getResponseCode(), exchange, userResponse);
            System.out.println("Product GET response code in PS: "+exchange.getResponseCode());
            exchange.close();
            return;

        }
        else {
                
            JSONObject jsonObject = new JSONObject();
            sendResponse(400, exchange, jsonObject.toString());
            exchange.close();
            return;

        }

    }

    private static String getRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder requestBody = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                requestBody.append(line);
            }
            return requestBody.toString();
        }
    }

    public static String sendPostRequest(String urlString, String requestBody) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        // Set the request method to POST
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json"); // Adjust content type if needed
        connection.setDoOutput(true);

        // Write the request body
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = requestBody.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        // Read the response
        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
        }

        return response.toString();
    }

    private static void sendResponse(Integer status, HttpExchange exchange, String response) throws IOException {
        exchange.sendResponseHeaders(status, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes(StandardCharsets.UTF_8));
        os.close();
    }

    public static String sendGetRequest(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection url_connection = (HttpURLConnection) url.openConnection();
        url_connection.setRequestMethod("GET");

        StringBuilder response = new StringBuilder();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(url_connection.getInputStream()))) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
        }

        url_connection.disconnect();

        return response.toString();
    }
    
}
