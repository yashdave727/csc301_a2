package ProductService;

import com.sun.net.httpserver.HttpServer;

import java.nio.file.Paths;

import java.io.IOException;

import java.net.InetSocketAddress;

import java.nio.file.Files;

import java.util.concurrent.Executors;

import org.json.JSONObject;


/*
 * act as a server handling requests related to product operations like creating, updating, 
 * getting, and deleting products
 */
public class ProductService {

    public static void main(String[] args) throws IOException {
        // Read JSON file content into a String
        String configPath =Paths.get("").toAbsolutePath().toString()+"/config.json";
   
        try {
            String content = new String(Files.readAllBytes(Paths.get(configPath)));
            JSONObject config = new JSONObject(content);
            JSONObject productService = config.getJSONObject("ProductService");
            int port = productService.getInt("port");
         
            System.out.println("Product Service Port: " + port);
            HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

            // Example: Set a custom executor with a fixed-size thread pool
            server.setExecutor(Executors.newFixedThreadPool(20)); // Adjust the pool size as needed
            
            // Set up context for /product requests
            server.createContext("/product", new ProductServiceHandler());

            server.setExecutor(null); // creates a default executor
            server.start();
            System.out.println("Server started on port " + port);

        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}