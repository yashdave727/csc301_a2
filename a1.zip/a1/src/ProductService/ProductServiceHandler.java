package ProductService;

import java.sql.*;

import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;

import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ProductServiceHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        String requestURI = exchange.getRequestURI().getPath().toString();
        System.out.println(requestURI);

        Connection connection = null;
        Statement statement = null;

        try {
            connection = DriverManager.getConnection("jdbc:sqlite:test.db");
            connection.setAutoCommit(false);
            System.out.println("Opened database successfully");
        } catch (SQLException e) {
            System.out.println("Database open unsuccessful");
            JSONObject jsonObject = new JSONObject();
            sendResponse(500, exchange, jsonObject.toString());
            exchange.close();
            return;
        }

        if (!checkTableExists("Products_Table", connection)) {
            
            createTable("Products_Table", connection);
        }

        if ("POST".equals(exchange.getRequestMethod())) {

            if (!requestURI.equals("/product")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            JSONObject requestJson;
            try {
                requestJson = new JSONObject(getRequestBody(exchange));
            } catch (JSONException | IOException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            String command;
            Integer id;
            String name;
            String description;
            Double price;
            Integer quantity;
            try {
                command = requestJson.getString("command");
                id = requestJson.getInt("id");
                name = requestJson.getString("name");
                description = requestJson.getString("description");
                price = requestJson.getDouble("price");
                quantity = requestJson.getInt("quantity");
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }


            if (id.equals(-1) || command.equals("")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            if (command.equals("create")) {

                try {

                    statement = connection.createStatement();
                    String query = "INSERT INTO Products_Table VALUES ("+id+", '"+name+"', '"+description+"', "+price+", "+quantity+")";
                    statement.executeUpdate(query);

                    JSONObject json = new JSONObject();
                    json.put("id", id);
                    json.put("name", name);
                    json.put("description", description);
                    json.put("price", price);
                    json.put("quantity", quantity);
                    String response = json.toString();

                    sendResponse(200, exchange, response);
                    exchange.close();
                    return;

                } catch (SQLException e) {
                    // SQLite error
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;
                } catch (JSONException e) {
                    // JSON error
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;
                }

            }

            else if (command.equals("update")) {

                try {

                    statement = connection.createStatement();
                    String query = "UPDATE Products_Table SET ";

                    boolean nameBool = false;
                    boolean descriptionBool = false;
                    boolean priceBool = false;
                    boolean quantityBool = false;
                    if (!name.equals("")) {
                        query += "name = "+"'"+name+"'";
                        nameBool = true;
                    }
                    if (!description.equals("")) {
                        query += ", description = "+"'"+description+"'";
                        descriptionBool = true;
                    }
                    if (!price.equals(-1)) {
                        query += ", price = "+price+"";
                        priceBool = true;
                    }
                    if (!quantity.equals(-1)) {
                        query += ", quantity = "+quantity;
                        priceBool = true;
                    }

                    if (nameBool || descriptionBool || priceBool || quantityBool) {
                        query += " WHERE id = "+id;

                        statement.executeUpdate(query);
                    }

                    JSONObject json = new JSONObject();
                    json.put("id", id);
                    json.put("name", name);
                    json.put("description", description);
                    json.put("price", price);
                    json.put("quantity", quantity);
                    String response = json.toString();

                    sendResponse(200, exchange, response);
                    exchange.close();
                    return;


                } catch (SQLException e) {
                    
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;

                } catch (JSONException e) {
                    // JSON error
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;
                }

            }

            else if (command.equals("delete")) {

                try {

                    statement = connection.createStatement();
                    String query = "DELETE FROM Products_Table WHERE id = "+id+" AND name = "+name+" AND description = "+description+" AND price = "+price+" AND quantity ="+quantity;
                    statement.executeUpdate(query);

                    JSONObject json = new JSONObject();
                    String response = json.toString();
                    sendResponse(200, exchange, response);
                    exchange.close();
                    return;

                } 
                
                catch (SQLException e) {
                   
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;

                }
            }

            else {
                
                JSONObject jsonObject = new JSONObject();
                sendResponse(401, exchange, jsonObject.toString());
                exchange.close();   
                return;

            }
        }

        else if ("GET".equals(exchange.getRequestMethod())) {
            
            String[] URISplit = requestURI.split("/");
            String id = URISplit[URISplit.length - 1];

            try {

                statement = connection.createStatement();
                String query = "SELECT * FROM Products_Table WHERE id = "+id;
                ResultSet user = statement.executeQuery(query);

                if (!user.next()) {

                JSONObject json = new JSONObject();
                sendResponse(404, exchange, json.toString());
                exchange.close();
                return;

                }

                JSONObject json = new JSONObject();

                while (user.next()) {
                    json.put("id", id);
                    json.put("name", user.getString("name"));
                    json.put("description", user.getString("description"));
                    json.put("price", user.getDouble("price"));
                    json.put("quantity", user.getInt("name"));
                }
                
                String response = json.toString();
                sendResponse(200, exchange, response);
                exchange.close();
                return;

            } 

            catch (SQLException e) {
               
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();   
                return;

            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();   
                return;
            }

        }
        
    }

    private static String getRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder requestBody = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                requestBody.append(line);
            }
            return requestBody.toString();
        }
    }

    public static String sendPostRequest(String urlString, String requestBody) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        // Set the request method to POST
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json"); // Adjust content type if needed
        connection.setDoOutput(true);

        // Write the request body
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = requestBody.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        // Read the response
        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
        }

        return response.toString();
    }

    private static void sendResponse(Integer status, HttpExchange exchange, String response) throws IOException {
        exchange.sendResponseHeaders(status, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes(StandardCharsets.UTF_8));
        os.close();
    }

    public static String sendGetRequest(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection url_connection = (HttpURLConnection) url.openConnection();
        url_connection.setRequestMethod("GET");

        StringBuilder response = new StringBuilder();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(url_connection.getInputStream()))) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
        }

        url_connection.disconnect();

        return response.toString();
    }

    private static boolean checkTableExists(String tableNameToCheck, Connection connection) {
        ResultSet tableNames;
        try {
            Statement statement = connection.createStatement();
            String query = "SELECT name FROM sqlite_master WHERE type='table' AND name='Users_Table';";
            tableNames = statement.executeQuery(query);
            while (tableNames.next()) {
                String tableName = tableNames.getString("name");
                if (tableName.equals(tableNameToCheck)) {
                    return true;
                }
            }
            statement.close();
        } 
        catch (SQLException e) {
            return false;
        }
        return false;
    }

    private static void createTable(String tableName, Connection connection) {
        try {
            Statement statement = connection.createStatement();
            String query =  "CREATE TABLE Users_Table" + 
                            "(id INT PRIMARY KEY     NOT NULL," +
                            "username TEXT           NOT NULL," +
                            "email    TEXT           NOT NULL," +
                            "password TEXT           NOT NULL)";   
            statement.executeUpdate(query);
            statement.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }

    private static void sendResponseBad(Integer status, HttpExchange exchange, Connection connection) throws IOException {
        JSONObject jsonObject = new JSONObject();
                try {
                    connection.close();
                } catch (SQLException e) {
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();
                    return;
                }
                sendResponse(status, exchange, jsonObject.toString());
                exchange.close();
                return;
    }

}
    

