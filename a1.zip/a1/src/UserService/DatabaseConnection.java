package UserService;

import java.sql.*;

public class DatabaseConnection {

    Connection connection;
    Statement statement;
    
    DatabaseConnection() {
        this.connection = null;
        this.statement = null;
    }

    public boolean checkTableExists(String tableNameToCheck) {
        ResultSet tableNames;
        try {
            this.statement = this.connection.createStatement();
            String query = "SELECT name FROM sqlite_master WHERE type='table' AND name='"+tableNameToCheck+"';";
            tableNames = statement.executeQuery(query);
        
            while (tableNames.next()) {
                String tableName = tableNames.getString("name");
                if (tableName.equals(tableNameToCheck)) {
                    return true;
                }
            }

            statement.close();
            return false;
        } catch (SQLException e) {
            return false;
        }
    }

}
