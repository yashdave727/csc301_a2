package UserService;

public class JSONServices {
    private JSONInner userService;
    private JSONInner orderService;
    private JSONInner productService;

    // Getters and setters
    // You need to generate getters and setters for all fields

    public JSONInner getUserService() {
        return userService;
    }

    public void setUserService(JSONInner userServiceNew) {
        this.userService = userServiceNew;
    }

    public JSONInner getOrderService() {
        return orderService;
    }

    public void setOrderService(JSONInner orderServiceNew) {
        this.orderService = orderServiceNew;
    }

    public JSONInner getProductService() {
        return productService;
    }

    public void setProductService(JSONInner productServiceNew) {
        this.productService = productServiceNew;
    }

    // Inner class for Address
    public static class JSONInner {
        private int port;
        private String ip;

        // Getters and setters for Address fields
        // You need to generate getters and setters for all fields

        public int getPort() {
            return port;
        }

        public void setStreet(int portNew) {
            this.port = portNew;
        }

        public String getIp() {
            return ip;
        }

        public void setCity(String ipNew) {
            this.ip = ipNew;
        }

    }
}
