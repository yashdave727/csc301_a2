package UserService;

import com.sun.net.httpserver.HttpServer;

import java.nio.file.Files;
import java.nio.file.Paths;

import java.io.IOException;

import java.net.InetSocketAddress;

import java.util.concurrent.Executors;

import org.json.JSONObject;

public class UserService {

    public static void main(String[] args) throws IOException {
        // Read JSON file content into a String
        String configPath = Paths.get("").toAbsolutePath().toString()+"/config.json";
   
        try {
            String content = new String(Files.readAllBytes(Paths.get(configPath)));
            JSONObject config = new JSONObject(content);
            JSONObject userService = config.getJSONObject("UserService");
            int port = userService.getInt("port");
         
            System.out.println("Order Service Port: " + port);
            HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

            // Example: Set a custom executor with a fixed-size thread pool
            server.setExecutor(Executors.newFixedThreadPool(20)); // Adjust the pool size as needed

            // Set up context for /user requests
            server.createContext("/user", new UserServiceHandler());

            server.setExecutor(null); // creates a default executor
            server.start();
            System.out.println("Server started on port " + port);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
