package UserService;

import java.sql.*;

import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;

import java.net.URL;
import java.nio.charset.StandardCharsets;

// import org.json.simple.JSONObject;
import org.json.JSONException;
import org.json.JSONObject;

public class UserServiceHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        String requestURI = exchange.getRequestURI().getPath().toString();
        System.out.println(requestURI);

        Connection connection = null;
        Statement statement = null;

        if (!checkTableExists("Users_Table", connection)) {
            createTable("Users_Table", connection);
        }

        if ("POST".equals(exchange.getRequestMethod())) {

            if (!requestURI.equals("/user")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            JSONObject requestJson;
            try {
                requestJson = new JSONObject(getRequestBody(exchange));
            } catch (JSONException | IOException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }

            String command;
            Integer id;
            String username;
            String email;
            String password;
            try {
                command = requestJson.getString("command");
                id = requestJson.getInt("id");
                username = requestJson.getString("username");
                email = requestJson.getString("email");
                password = requestJson.getString("password");
            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();
                return;
            }
            
            String hashedPassword = hash256(password);

            if (id.equals(-1) || command.equals("")) {

                JSONObject jsonObject = new JSONObject();
                sendResponse(400, exchange, jsonObject.toString());
                exchange.close();
                return;

            }

            if (command.equals("create")) {

                try {
                    Class.forName("org.sqlite.JDBC");
                    connection = DriverManager.getConnection("jdbc:sqlite:test.db");
                    connection.setAutoCommit(false);
                    System.out.println("Opened database successfully");

                    statement = connection.createStatement();
                    String query = "INSERT INTO Users_Table VALUES ("+id+", '"+username+"', '"+email+"', '"+hashedPassword+"')";
                    statement.executeUpdate(query);

                    JSONObject json = new JSONObject();
                    json.put("id", id);
                    json.put("username", username);
                    json.put("email", email);
                    json.put("password", hashedPassword);
                    String response = json.toString();

                    sendResponse(200, exchange, response);
                    exchange.close();
                    return;

                } catch (ClassNotFoundException e) {
                    // SQLite error
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;


                } catch (SQLException e) {
                    // SQLite error
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;
                } catch (JSONException e) {
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;
                }

            }

            else if (command.equals("update")) {

                try {
                    Class.forName("org.sqlite.JDBC");
                    connection = DriverManager.getConnection("jdbc:sqlite:test.db");
                    connection.setAutoCommit(false);
                    System.out.println("Opened database successfully");

                    statement = connection.createStatement();
                    String query = "UPDATE Users_Table SET ";

                    boolean usernameBool = false;
                    boolean emailBool = false;
                    boolean passwordBool = false;
                    if (!username.equals("")) {
                        query += "username = "+"'"+username+"'";
                        usernameBool = true;
                    }
                    if (!email.equals("")) {
                        query += " , email = "+"'"+email+"' ";
                        emailBool = true;
                    }
                    if (!password.equals("")) {
                        query += " , password = "+"'"+hashedPassword+"'";
                        passwordBool = true;
                    }

                    if (usernameBool || emailBool || passwordBool) {
                        query += " WHERE id = "+id;

                        statement.executeUpdate(query);
                    }

                    JSONObject json = new JSONObject();
                    json.put("id", id);
                    json.put("username", username);
                    json.put("email", email);
                    json.put("password", hashedPassword);
                    String response = json.toString();

                    sendResponse(200, exchange, response);
                    exchange.close();
                    return;


                } catch (ClassNotFoundException e) {

                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;

                } catch (SQLException e) {
                    
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;

                } catch (JSONException e) {
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;
                }

            }

            else if (command.equals("delete")) {

                try {
                    Class.forName("org.sqlite.JDBC");
                    connection = DriverManager.getConnection("jdbc:sqlite:test.db");
                    connection.setAutoCommit(false);
                    System.out.println("Opened database successfully");

                    statement = connection.createStatement();
                    String query = "DELETE FROM Users_Table WHERE id = "+id+" AND username = "+username+" AND email = "+email+" AND password = "+hashedPassword;
                    statement.executeUpdate(query);

                    // Is this empty or do you want empty String
                    JSONObject json = new JSONObject();
                    String response = json.toString();
                    sendResponse(200, exchange, response);
                    exchange.close();
                    return;

                } 
                catch (ClassNotFoundException e) {
                    
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;

                } 
                catch (SQLException e) {
                   
                    JSONObject jsonObject = new JSONObject();
                    sendResponse(500, exchange, jsonObject.toString());
                    exchange.close();   
                    return;

                }
            }

            else {
                
                JSONObject jsonObject = new JSONObject();
                sendResponse(401, exchange, jsonObject.toString());
                exchange.close();   
                return;

            }
        }

        else if ("GET".equals(exchange.getRequestMethod())) {
            
            String[] URISplit = requestURI.split("/");
            String id = URISplit[URISplit.length - 1];

            try {
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection("jdbc:sqlite:test.db");
                connection.setAutoCommit(false);
                System.out.println("Opened database successfully");

                statement = connection.createStatement();
                String query = "SELECT * FROM Users_Table WHERE id = "+id;
                ResultSet user = statement.executeQuery(query);

                if (!user.next()) {

                JSONObject json = new JSONObject();
                sendResponse(404, exchange, json.toString());
                exchange.close();
                return;

                }

                JSONObject json = new JSONObject();
                while (user.next()) {
                    json.put("id", id);
                    json.put("name", user.getString("name"));
                    json.put("description", user.getString("description"));
                    json.put("price", user.getDouble("price"));
                    json.put("quantity", user.getInt("name"));
                }
                String response = json.toString();
                sendResponse(200, exchange, response);
                exchange.close();
                return;

            } 
            catch (ClassNotFoundException e) {
                
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();   
                return;

            } 
            catch (SQLException e) {
               
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();   
                return;

            } catch (JSONException e) {
                JSONObject jsonObject = new JSONObject();
                sendResponse(500, exchange, jsonObject.toString());
                exchange.close();   
                return;
            }

        }
        
    }

    private static String getRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder requestBody = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                requestBody.append(line);
            }
            return requestBody.toString();
        }
    }

    public static String sendPostRequest(String urlString, String requestBody) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        // Set the request method to POST
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json"); // Adjust content type if needed
        connection.setDoOutput(true);

        // Write the request body
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = requestBody.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        // Read the response
        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
        }

        return response.toString();
    }

    private static void sendResponse(Integer status, HttpExchange exchange, String response) throws IOException {
        exchange.sendResponseHeaders(status, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes(StandardCharsets.UTF_8));
        os.close();
    }

    public static String sendGetRequest(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection url_connection = (HttpURLConnection) url.openConnection();
        url_connection.setRequestMethod("GET");

        StringBuilder response = new StringBuilder();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(url_connection.getInputStream()))) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
        }

        url_connection.disconnect();

        return response.toString();
    }

    private static boolean checkTableExists(String tableNameToCheck, Connection connection) {
        ResultSet tableNames;
        try {
            Statement statement = connection.createStatement();
            String query = "SELECT name FROM sqlite_master WHERE type='table' AND name='Users_Table';";
            tableNames = statement.executeQuery(query);
            while (tableNames.next()) {
                String tableName = tableNames.getString("name");
                if (tableName.equals(tableNameToCheck)) {
                    return true;
                }
            }
            statement.close();
        } 
        catch (SQLException e) {
            return false;
        }
        return false;
    }

    private static void createTable(String tableName, Connection connection) {
        try {
            Statement statement = connection.createStatement();
            String query =  "CREATE TABLE Users_Table" + 
                            "(id INT PRIMARY KEY     NOT NULL," +
                            "username TEXT           NOT NULL," +
                            "email    TEXT           NOT NULL," +
                            "password TEXT           NOT NULL)";   
            statement.executeUpdate(query);
            statement.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }

    private static String hash256(String password) {

        if (password.equals("")) {
            return "";
        }

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

}
    

