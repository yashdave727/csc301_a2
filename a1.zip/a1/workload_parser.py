# WorkloadParser:
# A parser which reads a given workload file (samples are provided).
# You are encouraged to modify this workload file for your own testing.
# The workload parser makes an HTTP request to the OrderService using the exact API as specified
# for the User and Product service. See architecture.png for a conceptual visualization.
# Note: This can be written in any programming language as long as it runs on the labs
# without needing to install anything.

import requests
import json
import sys
import os

class WorkloadParser:

  def __init__(self, file_path, config_path):
    self.file_path = file_path
    self.config = self.load_config(config_path)
    self.order_service_base_url = f"http://{self.config['OrderService']['ip']}:{self.config['OrderService']['port']}"

  def load_config(self, config_path):
    with open(config_path, 'r') as file:
      return json.load(file)

  def parse_line(self, line):
    parts = line.split()
    if not parts or (parts[0] != 'USER' and parts[0] != 'PRODUCT' and parts[0] != 'ORDER'):
      return None
    
    account_type = parts[0] # USER, PRODUCT, ORDER
    action = parts[1]  # create, get, update, delete
    id_ = parts[2] if len(parts) > 2 else None
    return account_type, action, id_, parts[3:]

  def make_request(self, account_type, action, id_, params):
    headers = {'Content-Type': 'application/json'}
    data = {}

    if account_type == "USER":
      if action in ['create', 'update', 'delete']:
          print("Reached POST commands in Parser")
          url = f'{self.order_service_base_url}/order/user'
          method = 'POST'
          data = {
              "command": action,
              "id": id_,
              "username": params[0],
              "email": params[1],
              "password": params[2]
          }
      elif action == 'get':
        url = f'{self.order_service_base_url}/order/user/'
        method = 'GET'
            # no data passed in get method ?

    elif account_type == "PRODUCT":
      if action in ['create', 'update', 'delete']:
        url = f'{self.order_service_base_url}/order/product'
        method = 'POST'
        data = {
            "command": action,
            "id": id_,
            "name": params[0],
            "description": params[1],
            "price": params[2],
            "quantity": params[3]
        }

      elif action == 'info':
        url = f'{self.order_service_base_url}/order/product/{id_}'
        method = 'GET'
            # no data passed in get method

    elif account_type == "ORDER":
        url = f'{self.order_service_base_url}/order'
        method = 'POST'
        data = {
            "command": "place",
            "product_id": id_,
            "user_id": params[0],
            "quantity": params[1]
        }

    data = json.dumps(data)

    # Handle the request based on the method
    if method == 'POST':
        response = requests.post(url, json=data, headers=headers)
    elif method == 'GET':
        response = requests.get(url, headers=headers)

    return response

  def process_workload(self):
    with open(self.file_path, 'r') as file:
      for line in file:
        parsed_line = self.parse_line(line)
        if parsed_line:
          account_type, action, id_, params = parsed_line
          response = self.make_request(account_type, action, id_, params)
          print(
              f'Action: {action}, User ID: {id_}, Response: {response.status_code}'
          )


if __name__ == "__main__":
  config_path = os.getcwd() + "/config.json"
  print(config_path)
  workload_file_path = sys.argv[1]
  parser = WorkloadParser(workload_file_path, config_path)
  parser.process_workload()
